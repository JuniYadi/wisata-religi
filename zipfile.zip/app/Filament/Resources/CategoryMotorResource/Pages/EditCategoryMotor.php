<?php

namespace App\Filament\Resources\CategoryMotorResource\Pages;

use App\Filament\Resources\CategoryMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditCategoryMotor extends EditRecord
{
    protected static string $resource = CategoryMotorResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
