<?php

namespace App\Filament\Resources\CategoryMotorResource\Pages;

use App\Filament\Resources\CategoryMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListCategoryMotors extends ListRecords
{
    protected static string $resource = CategoryMotorResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
