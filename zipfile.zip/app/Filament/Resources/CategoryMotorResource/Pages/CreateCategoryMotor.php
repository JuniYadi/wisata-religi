<?php

namespace App\Filament\Resources\CategoryMotorResource\Pages;

use App\Filament\Resources\CategoryMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCategoryMotor extends CreateRecord
{
    protected static string $resource = CategoryMotorResource::class;

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
