<?php

namespace App\Filament\Resources;

use App\Filament\Resources\LokasiPenjemputanResource\Pages;
use App\Filament\Resources\LokasiPenjemputanResource\RelationManagers;
use App\Models\LokasiPenjemputan;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class LokasiPenjemputanResource extends Resource
{
    protected static ?string $model = LokasiPenjemputan::class;

    protected static ?string $navigationIcon = 'heroicon-o-map-pin';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('nama')
                    ->required(),
                Forms\Components\Textarea::make('alamat')
                    ->required()
                    ->columnSpanFull(),
                Forms\Components\TextInput::make('fee_pickup')
                    ->required()
                    ->numeric()
                    ->prefix('Rp. '),
                Forms\Components\TextInput::make('fee_dropoff')
                    ->required()
                    ->numeric()
                    ->prefix('Rp. '),
                Forms\Components\Toggle::make('isActive')
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('nama')
                    ->searchable(),
                Tables\Columns\IconColumn::make('isActive')
                    ->boolean(),
                Tables\Columns\TextColumn::make('fee_pickup')
                    ->numeric()
                    ->money('Rp.')
                    ->sortable(),
                Tables\Columns\TextColumn::make('fee_dropoff')
                    ->numeric()
                    ->money('Rp.')
                    ->sortable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListLokasiPenjemputans::route('/'),
            'create' => Pages\CreateLokasiPenjemputan::route('/create'),
            'edit' => Pages\EditLokasiPenjemputan::route('/{record}/edit'),
        ];
    }
}
