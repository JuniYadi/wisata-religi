<?php

namespace App\Filament\Resources\LokasiPenjemputanResource\Pages;

use App\Filament\Resources\LokasiPenjemputanResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListLokasiPenjemputans extends ListRecords
{
    protected static string $resource = LokasiPenjemputanResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
