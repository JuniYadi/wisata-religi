<?php

namespace App\Filament\Resources\TypeMotorResource\Pages;

use App\Filament\Resources\TypeMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListTypeMotors extends ListRecords
{
    protected static string $resource = TypeMotorResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
