<?php

namespace App\Filament\Resources\TypeMotorResource\Pages;

use App\Filament\Resources\TypeMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTypeMotor extends CreateRecord
{
    protected static string $resource = TypeMotorResource::class;

    protected function getRedirectUrl(): string
    {
        return $this->getResource()::getUrl('index');
    }
}
