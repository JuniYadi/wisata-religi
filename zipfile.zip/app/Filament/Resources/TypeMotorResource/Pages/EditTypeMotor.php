<?php

namespace App\Filament\Resources\TypeMotorResource\Pages;

use App\Filament\Resources\TypeMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditTypeMotor extends EditRecord
{
    protected static string $resource = TypeMotorResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
