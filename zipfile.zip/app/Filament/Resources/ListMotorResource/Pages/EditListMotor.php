<?php

namespace App\Filament\Resources\ListMotorResource\Pages;

use App\Filament\Resources\ListMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditListMotor extends EditRecord
{
    protected static string $resource = ListMotorResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
