<?php

namespace App\Filament\Resources\ListMotorResource\Pages;

use App\Filament\Resources\ListMotorResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateListMotor extends CreateRecord
{
    protected static string $resource = ListMotorResource::class;
}
