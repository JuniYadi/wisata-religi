<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ListMotorResource\Pages;
use App\Filament\Resources\ListMotorResource\RelationManagers;
use App\Models\ListMotor;
use App\Models\TypeMotor;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class ListMotorResource extends Resource
{
    protected static ?string $model = ListMotor::class;

    protected static ?string $navigationIcon = 'heroicon-o-circle-stack';
    protected static ?string $navigationGroup = 'Motors';
    // protected static ?int $navigationSort = 3;

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('type_motor_id')
                    ->options(TypeMotor::all()->pluck('name', 'id'))
                    ->label('Type Motor')
                    ->searchable()
                    ->required(),
                Forms\Components\TextInput::make('nomor_rangka')
                    ->required(),
                Forms\Components\TextInput::make('plat_nomor')
                    ->required(),
                Forms\Components\Select::make('status')
                    ->options(ListMotor::status())
                    ->searchable()
                    ->required(),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('typeMotor.name')
                    ->label('Type Motor')
                    ->sortable(),
                Tables\Columns\TextColumn::make('nomor_rangka')
                    ->searchable(),
                Tables\Columns\TextColumn::make('plat_nomor')
                    ->searchable(),
                Tables\Columns\TextColumn::make('status')
                    ->searchable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                Tables\Columns\TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListListMotors::route('/'),
            'create' => Pages\CreateListMotor::route('/create'),
            'edit' => Pages\EditListMotor::route('/{record}/edit'),
        ];
    }
}
