<?php

namespace App\Http\Controllers;

use App\Models\CategoryMotor;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function homepage()
    {
        $categoryMotors = CategoryMotor::all();

        return view('welcome', compact('categoryMotors'));
    }

    public function listMotor(Request $request, $id)
    {
        $categoryMotor = CategoryMotor::with([
            'typeMotor',
            'typeMotor.listMotor' => function($query) {
                $query->where('status', 'TERSEDIA');
            }])
            ->findOrFail($id);;

        // If you need to return the view with the categoryMotor
        return view('list-motor', compact('categoryMotor'));
    }
}
