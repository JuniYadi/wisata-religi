<?php

namespace App\Http\Controllers;

use App\Models\LokasiPenjemputan;
use App\Models\Order;
use App\Models\TypeMotor;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Payment;
use Illuminate\Support\Facades\Log;

class OrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $orders = Order::with(['motor', 'user', 'dropoffLocation', 'pickupLocation'])
            ->where('user_id', auth()->id())
            ->paginate(10);

        $getPayments = Payment::getPaymentLists();
        $payments = [];
        foreach($getPayments as $gp) {
            $payments[$gp['paymentMethod']] = $gp['paymentName'];
        }

        return view('order.index', compact('orders', 'payments'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {
        $getLokasiPenjemputan = LokasiPenjemputan::getPickup();
        $lokasiPickup = $getLokasiPenjemputan['lokasiPickup'];
        $lokasiDropoff = $getLokasiPenjemputan['lokasiDropoff'];

        $typeMotorId = $request->input('typemotor_id');
        $typeMotor = TypeMotor::with([
            'category',
            'listMotor' => function($query) {
                $query->where('status', 'TERSEDIA');
            }])->findOrFail($typeMotorId);

        $typeMotorName = $typeMotor->nama;

        $minDate = Carbon::now()->format('Y-m-d H:m');
        $maxDate = Carbon::now()->addDays(14)->format('Y-m-d H:m');

        if ($typeMotor->listMotor->count() <= 0) {
            session()->flash('flash.banner', "Maaf stock motor $typeMotorName sedang kosong, Silahkan pilih type motor lainnya.!");
            session()->flash('flash.bannerStyle', 'danger');

            return redirect('/');
        }

        $getPayments = Payment::getPaymentLists([
            'paymentMethod' => [
                'VC', // Kartu Kredit
                'BC', // BCA VA
                'I1', // BNI VA
                'M1', // MANDIRI VA
                'BR' // BRI VA
            ]
        ]);
        $payments = [];
        $payments[] = [
            "value" => "cash",
            "label" => "CASH"
        ];
        foreach($getPayments as $gp) {
            $payments[] = [
                "value" => $gp['paymentMethod'],
                "label" => $gp['paymentName']
            ];
        }

        $data = compact('lokasiPickup', 'lokasiDropoff', 'typeMotor', 'typeMotorId', 'minDate', 'maxDate', 'payments');

        return view('order.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $getPayments = Payment::getPaymentLists([
            'paymentMethod' => [
                'VC', // Kartu Kredit
                'BC', // BCA VA
                'I1', // BNI VA
                'M1', // MANDIRI VA
                'BR' // BRI VA
            ]
        ]);

        // convert paymentMethod to array
        $paymentMethod = [];
        foreach($getPayments as $gp) {
            $paymentMethod[] = $gp['paymentMethod'];
        }

        // convert to array to string
        $paymentMethodAllowed = implode(',', $paymentMethod);

        $request->validate([
            'dropoff_location_id' => 'required|exists:lokasi_penjemputans,id',
            'dropoff_location_id' => 'required|exists:lokasi_penjemputans,id',
            'motor_id' => 'required|exists:type_motors,id',
            'pickupTime' => 'required|date',
            'dropoffTime' => 'required|date',
            'payment' => 'required|in:cash,' . $paymentMethodAllowed,
            'phoneNumber' => 'required|string|min:11|max:15',
            'identity' => 'required|in:ktp,sim,pasport',
        ]);

        // get safe data
        $user = auth()->user();
        $dataInput = $request->only([
            'dropoff_location_id',
            'pickup_location_id',
            'motor_id',
            'pickupTime',
            'dropoffTime',
            'payment',
            'phoneNumber',
            'identity'
        ]);

        // parse two time
        $pickupTime = Carbon::parse($dataInput['pickupTime']);
        $dropoffTime = Carbon::parse($dataInput['dropoffTime']);

        // compare
        if ($pickupTime->diffInMinutes($dropoffTime) < 0) {
            session()->flash('flash.banner', 'Waktunya pengembalian motor harus setelah waktunya pengambilan motor!');
            session()->flash('flash.bannerStyle', 'danger');

            return redirect()->back();
        }

        // get diff days
        $diffDays = $pickupTime->diffInDays($dropoffTime);

        // get motor detail
        $typeMotor = TypeMotor::findOrFail($dataInput['motor_id']);
        // get location detail
        $pickupLocation = LokasiPenjemputan::findOrFail($dataInput['pickup_location_id']);
        $dropoffLocation = LokasiPenjemputan::findOrFail($dataInput['dropoff_location_id']);

        // calculate price
        $total = ($typeMotor->price * $diffDays) + ($pickupLocation->fee_pickup + $dropoffLocation->fee_dropoff);

        $order = Order::create([
            'user_id' => $user->id,
            'motor_id' => $dataInput['motor_id'],
            'motor_name' => $typeMotor->name,
            'motor_price' => $typeMotor->price,
            'days' => $diffDays,
            'identity' => $dataInput['identity'],
            'name' => $user->name,
            'email' => $user->email,
            'phone_number' => $dataInput['phoneNumber'] ?? $user->phone_number,
            'payment' => $dataInput['payment'],
            'dropoff_date' => $dropoffTime,
            'dropoff_location_fee' => $dropoffLocation->fee_dropoff,
            'dropoff_location_id' => $dataInput['dropoff_location_id'],
            'pickup_date' => $pickupTime,
            'pickup_location_fee' => $pickupLocation->fee_pickup,
            'pickup_location_id' => $dataInput['pickup_location_id'],
            'status' => 'PENDING_PAYMENT',
            'total' => $total
        ]);

        if($order->payment !== "cash") {
            return redirect()->route('order.bayar', $order->id);
        }

        return redirect()->route('order.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Order $order)
    {
        // relation
        $order->load(['motor', 'user', 'dropoffLocation', 'pickupLocation', 'payment']);

        return view('order.view', compact('order'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Order $order)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Order $order)
    {
        //
    }

    public function getPaymentMethod()
    {
        try {
            $duitkuConfig = new \Duitku\Config(
                env('DUITKU_MERCHANT_KEY'), env('DUITKU_MERCHANT_CODE')
            );

            $paymentAmount = "10000"; //"YOUR_AMOUNT";
            $paymentMethodList = \Duitku\Api::getPaymentMethod($paymentAmount, $duitkuConfig);

            return json_decode($paymentMethodList);
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }

    public function bayar($id)
    {
        $order = Order::findOrFail($id);

        if($order->status !== "PENDING_PAYMENT") {
            return redirect()->route('order.index')->with('flash.banner', 'Order sudah dalam status ' . $order->status)->with('flash.bannerStyle', 'info');
        }

        $duitkuConfig = new \Duitku\Config(
            env('DUITKU_MERCHANT_KEY'), env('DUITKU_MERCHANT_CODE')
        );
        $duitkuConfig->setSandboxMode(env('DUITKU_SANDBOX_MODE'));
        // set sanitizer (default : true)
        $duitkuConfig->setSanitizedMode(false);

        $params = array(
            'paymentAmount'     => (int) $order->total,
            'paymentMethod'     => $order->payment,
            'merchantOrderId'   => $order->id,
            'productDetails'    => "Pembayaran Order " . $order->id,
            'customerVaName'    => $order->name,
            'email'             => $order->email,
            'callbackUrl'       => route('order.callback'),
            'returnUrl'         => route('order.show', $order->id),
            'expiryPeriod'      => 120
        );

        try {
            // createInvoice Request
            $responseDuitkuApi = \Duitku\Api::createInvoice($params, $duitkuConfig);
            $resp = json_decode($responseDuitkuApi);

            return redirect()->to($resp->paymentUrl);
        } catch (\Exception $e) {
            session()->flash('flash.banner', $e->getMessage());
            session()->flash('flash.bannerStyle', 'danger');

            return redirect()->route('order.index');

        }
    }

    public function callback(Request $request)
    {
        Log::debug($request->all());

        $request->validate([
            'merchantCode' => 'required',
            'amount' => 'required',
            'merchantOrderId' => 'required',
            'productDetail' => 'required',
            'signature' => 'required',
            'paymentCode' => 'required',
            'reference' => 'required',
        ]);

        Log::debug('Lolos Validate');

        $input = $request->only([
            'merchantCode',
            'amount',
            'merchantOrderId',
            'productDetail',
            'signature',
            'paymentCode',
            'reference',
            'settlementDate',
        ]);

        Log::debug("Ambil Input", $input);

        try {
            $validationSignature = \App\Helpers\Duitku::callback_validate($input['signature'], [
                'merchantOrderId' => $input['merchantOrderId'],
                'paymentAmount' => $input['amount'],
            ]);

            if (!$validationSignature) {
                Log::debug("Signature is invalid");

                return response()->json([
                    'status' => 'error',
                    'message' => 'Signature is invalid'
                ]);
            }

            // check the order
            $order = Order::findOrFail($input['merchantOrderId']);

            // save payment detail
            Payment::create([
                'order_id' => $input['merchantOrderId'],
                'user_id' => $order->user_id,
                'amount' => $input['amount'],
                'paymentCode' => $input['paymentCode'],
                'reference' => $input['reference'],
                'status' => 'LUNAS'
            ]);

            // update order
            $order->status = 'LUNAS';
            $order->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Signature is valid'
            ]);

        } catch (\Exception $e) {
            Log::error($e);
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ]);
        }
    }
}
