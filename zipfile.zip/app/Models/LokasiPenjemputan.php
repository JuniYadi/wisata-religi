<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Number;

class LokasiPenjemputan extends Model
{
    use HasFactory;

    protected $fillable = [
        'nama',
        'alamat',
        'isActive',
        'fee_pickup',
        'fee_dropoff'
    ];

    protected $casts = [
        'isActive' => 'boolean',
        'fee_pickup' => 'double',
        'fee_dropoff' => 'double'
    ];

    public static function getPickup()
    {
        $getLokasiPenjemputan = self::all();
        $lokasiPickup = [];
        $lokasiDropoff = [];
        foreach ($getLokasiPenjemputan as $lokasi) {
            $lokasiPickup[] = [
                "value" => $lokasi->id,
                "label" => $lokasi->nama . ' - ' . $lokasi->alamat . ' - Biaya : ' . Number::currency($lokasi->fee_pickup, 'IDR')
            ];
            $lokasiDropoff[] = [
                "value" => $lokasi->id,
                "label" => $lokasi->nama . ' - ' . $lokasi->alamat . ' - Biaya : ' . Number::currency($lokasi->fee_dropoff, 'IDR')
            ];
        }

        return compact('lokasiPickup', 'lokasiDropoff');
    }
}
