<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategoryMotor extends Model
{
    use HasFactory;

    protected $fillable = ['description', 'image', 'name', 'price', 'stocks'];

    public function typeMotor()
    {
        return $this->hasMany(TypeMotor::class, 'category_id', 'id');
    }
}
