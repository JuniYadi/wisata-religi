<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'motor_id',
        'motor_name',
        'motor_price',
        'days',
        'name',
        'email',
        'identity',
        'payment',
        'phone_number',
        'dropoff_date',
        'dropoff_date_execute',
        'dropoff_location_fee',
        'dropoff_location_id',
        'pickup_date',
        'pickup_date_execute',
        'pickup_location_fee',
        'pickup_location_id',
        'status',
        'total'
    ];

    public function motor()
    {
        return $this->belongsTo(TypeMotor::class, 'motor_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function dropoffLocation()
    {
        return $this->belongsTo(LokasiPenjemputan::class, 'dropoff_location_id', 'id');
    }

    public function pickupLocation()
    {
        return $this->belongsTo(LokasiPenjemputan::class, 'pickup_location_id', 'id');
    }

    public function payment()
    {
        return $this->belongsTo(Payment::class, 'payment', 'id');
    }
}
