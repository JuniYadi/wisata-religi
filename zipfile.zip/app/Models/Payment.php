<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'user_id',
        'amount',
        'paymentCode',
        'reference',
        'status'
    ];

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function getPaymentLists($filter = null) : array
    {
        $paymentOptions = [
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/VA.PNG',
                'paymentMethod' => 'VA',
                'paymentName' => 'MAYBANK VA',
                'totalFee' => '3000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/RETAIL.PNG',
                'paymentMethod' => 'FT',
                'paymentName' => 'RETAIL',
                'totalFee' => '7500',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/VC.PNG',
                'paymentMethod' => 'VC',
                'paymentName' => 'CREDIT CARD',
                'totalFee' => '2790',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/PERMATA.PNG',
                'paymentMethod' => 'BT',
                'paymentName' => 'PERMATA VA',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/B1.PNG',
                'paymentMethod' => 'B1',
                'paymentName' => 'CIMB NIAGA VA',
                'totalFee' => '3000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/A1.PNG',
                'paymentMethod' => 'A1',
                'paymentName' => 'ATM BERSAMA VA',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/I1.PNG',
                'paymentMethod' => 'I1',
                'paymentName' => 'BNI VA',
                'totalFee' => '3000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/OV.PNG',
                'paymentMethod' => 'OV',
                'paymentName' => 'OVO',
                'totalFee' => '150',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/MV.PNG',
                'paymentMethod' => 'M1',
                'paymentName' => 'MANDIRI VA',
                'totalFee' => '4000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/MV.PNG',
                'paymentMethod' => 'M2',
                'paymentName' => 'MANDIRI VA H2H',
                'totalFee' => '3000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/AG.JPG',
                'paymentMethod' => 'AG',
                'paymentName' => 'ARTHA GRAHA VA',
                'totalFee' => '3000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/SHOPEEPAY.PNG',
                'paymentMethod' => 'SP',
                'paymentName' => 'SHOPEEPAY QRIS',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/DN.PNG',
                'paymentMethod' => 'DN',
                'paymentName' => 'INDODANA PAYLATER',
                'totalFee' => '100',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/LINKAJA.PNG',
                'paymentMethod' => 'LA',
                'paymentName' => 'LINKAJA APP PCT',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/SHOPEEPAY.PNG',
                'paymentMethod' => 'SA',
                'paymentName' => 'SHOPEEPAY APP',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/LINKAJA.PNG',
                'paymentMethod' => 'LQ',
                'paymentName' => 'LINKAJA QRIS',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/DA.PNG',
                'paymentMethod' => 'DA',
                'paymentName' => 'DANA',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/BCA.SVG',
                'paymentMethod' => 'BC',
                'paymentName' => 'BCA VA',
                'totalFee' => '5000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/IR.PNG',
                'paymentMethod' => 'IR',
                'paymentName' => 'INDOMARET',
                'totalFee' => '6000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/SHOPEEPAY.PNG',
                'paymentMethod' => 'SL',
                'paymentName' => 'SHOPEEPAY LINK',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/BR.PNG',
                'paymentMethod' => 'BR',
                'paymentName' => 'BRI VA',
                'totalFee' => '4000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/NC.PNG',
                'paymentMethod' => 'NC',
                'paymentName' => 'BNC VA',
                'totalFee' => '4000',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/NQ.PNG',
                'paymentMethod' => 'NQ',
                'paymentName' => 'NOBU QRIS',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/OV.PNG',
                'paymentMethod' => 'OL',
                'paymentName' => 'OVO LINK',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/JP.PNG',
                'paymentMethod' => 'JP',
                'paymentName' => 'JENIUS PAY',
                'totalFee' => '0',
            ],
            [
                'paymentImage' => 'https://images.duitku.com/hotlink-ok/GQ.PNG',
                'paymentMethod' => 'GQ',
                'paymentName' => 'GUDANG VOUCHER QRIS',
                'totalFee' => '0',
            ],
        ];

        // filter by code
        if ($filter) {
            $paymentMehod = $filter['paymentMethod'];

            // filter by code
            $paymentOptions = array_filter($paymentOptions, function ($payment) use ($paymentMehod) {
                return in_array($payment['paymentMethod'], $paymentMehod);
            });
        }

        return $paymentOptions;
    }
}
