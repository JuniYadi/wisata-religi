<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ListMotor extends Model
{
    use HasFactory;

    protected $fillable = ['nomor_rangka', 'plat_nomor', 'status', 'type_motor_id'];

    public function typeMotor()
    {
        return $this->belongsTo(TypeMotor::class);
    }

    public function order()
    {
        
    }

    public static function status()
    {
        return [
            "TERSEDIA" => "TERSEDIA",
            "SEDANG_DIPINJAM" => "SEDANG DI PINJAM",
            "SEDANG_DIPERBAIKI" => "SEDANG DI PERBAIKI",
            "SEDANG_PROSES_PENGEMBALIAN" => "SEDANG PROSES PENGEMBALIAN",
            "RUSAK" => "RUSAK",
        ];
    }
}
