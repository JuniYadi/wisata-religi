<?php

namespace App\Helpers;

use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class Duitku {
    public static function signature($params) {
        return md5(env('DUITKU_MERCHANT_CODE') . $params['merchantOrderId'] . $params['paymentAmount'] . env('DUITKU_MERCHANT_KEY'));
    }

    public static function callback_validate($sign, $params) {
        $merchantOrderId = $params['merchantOrderId'];
        $paymentAmount = $params['paymentAmount'];

        $signature = env('DUITKU_MERCHANT_CODE') . $paymentAmount . $merchantOrderId . env('DUITKU_MERCHANT_KEY');
        $signatureMD5 = md5($signature);

        return $signatureMD5 === $sign;
    }

    public static function create($params) {
        $payload = [
            "merchantCode" => env('DUITKU_MERCHANT_CODE'),
            "paymentAmount" => $params['payment_amount'],
            "paymentMethod" => $params['duitku_payment_code'],
            "merchantOrderId" => $params['order_id'],
            "productDetails" => $params['product_details'],
            "customerVaName" => $params['customer_name'],
            "email" => $params['customer_email'],
            "callbackUrl" => $params['callback_url'],
            "returnUrl" => $params['redirect_url'],
            "expiryPeriod" => $params['expired'] ?? 120,
        ];

        $payload['signature'] = self::signature([
            'merchantOrderId' => $payload['merchantOrderId'],
            'paymentAmount' => $payload['paymentAmount']
        ]);

        Log::debug($payload);

        $response = Http::withHeaders([
            'accept' => 'application/json',
            'content-type' => 'application/json',
        ])->post(env('DUITKU_URI'), ['json' => $payload]);

        if ($response->status() != 200) {
            throw new Exception('Failed to create payment: ' . $response->body());
        }

        return json_decode($response->getBody(), true);
    }

}
