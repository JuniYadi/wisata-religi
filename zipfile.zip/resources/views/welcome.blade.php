<x-app-layout>

    <section class="bg-white dark:bg-gray-900">
        <div class="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-12">
            <div class="mr-auto place-self-center lg:col-span-7">
                <h1 class="max-w-2xl mb-4 text-4xl font-extrabold tracking-tight leading-none md:text-5xl xl:text-6xl dark:text-white">
                    Kami Menawarkan Motor dengan <span id="element-type" class="text-blue-600"></span>
                </h1>
                <p class="max-w-2xl mb-6 font-light text-gray-500 lg:mb-8 md:text-lg lg:text-xl dark:text-gray-400">
                    Anda butuh motor untuk kegiatan sehari-hari? Atau Anda ingin liburan ke luar kota? Sewa motor di sini saja. Kami menyediakan motor dengan harga terjangkau dan kualitas terbaik. Kami juga menyediakan berbagai jenis motor, seperti motor bebek, motor matic, dan motor sport.
                </p>
                <button type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                Masuk
                <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                </svg>
                </button>
            </div>
            <div class="hidden lg:mt-0 lg:col-span-5 lg:flex">
                <img src="/image/heroimage.png" alt="mockup">
            </div>
        </div>
    </section>

    <section class="bg-white dark:bg-gray-900">

        <h2 class="text-2xl font-semibold text-gray-900 dark:text-white text-center mx-auto">
            Kategori Motor
        </h2>

        <div class="grid max-w-screen-xl px-4 py-8 mx-auto lg:gap-8 xl:gap-0 lg:py-16 lg:grid-cols-3">

            @foreach($categoryMotors as $cm)
                <div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                    <a href="{{ route('listMotor', $cm->id) }}">
                        <img class="p-8 rounded-t-lg" src="{{ asset('storage/'.$cm->image) }}" alt="product image" />
                    </a>
                    <div class="px-5 pb-5">
                        <a href="{{ route('listMotor', $cm->id) }}">
                            <h3 class="text-4xl font-semibold tracking-tight text-gray-900 dark:text-white">
                                {{ $cm->name }}
                            </h3>
                        </a>
                        <div class="flex mb-2 items-center justify-between">
                            <h4 class="text-xl font-semibold text-gray-900 dark:text-white">
                                {{ \Illuminate\Support\Number::currency($cm->price, 'IDR') }}
                            </h4>

                            @if($cm->stocks > 0)

                            <a href="{{ route('listMotor', $cm->id) }}" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                Sewa
                            </a>

                            @else

                            <button class="bg-gray-400 text-white font-medium rounded-lg text-sm px-5 py-2.5 text-center cursor-not-allowed" disabled>
                                Sold out
                            </button>

                            @endif
                        </div>
                    </div>
                </div>
            @endforeach

        </div>

    </section>



</x-app-layout>
