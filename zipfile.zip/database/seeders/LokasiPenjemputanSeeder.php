<?php

namespace Database\Seeders;

use App\Models\LokasiPenjemputan;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class LokasiPenjemputanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            [
                'nama' => 'Kantor Pusat',
                'alamat' => 'Jl. Contoh Kantor Kami, Malang, Jawa Timur',
                'isActive' => true,
                'fee_pickup' => 0,
                'fee_dropoff' => 0,
            ],
            [
                'nama' => 'Stasiun Kota Lama',
                'alamat' => 'Jl. Contoh Stasiun Kota Lama, Malang, Jawa Timur',
                'isActive' => true,
                'fee_pickup' => 25000,
                'fee_dropoff' => 25000,
            ],
            [
                'nama' => 'Terminal Bus',
                'alamat' => 'Jl. Terminal Bus A, Malang, Jawa Timur',
                'isActive' => true,
                'fee_pickup' => 25000,
                'fee_dropoff' => 25000,
            ],
        ];

        LokasiPenjemputan::insert($data);
    }
}
