<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('motor_id')
                ->nullable()
                ->references('id')->on('list_motors')
                ->onDelete('set null');
            $table->string('motor_name');
            $table->double('motor_price');
            $table->integer('days')->unsigned();
            $table->string('name');
            $table->string('email');
            $table->string('identity');
            $table->string('payment');
            $table->string('phone_number');
            $table->dateTime('dropoff_date_execute')->nullable();
            $table->dateTime('dropoff_date');
            $table->double('dropoff_location_fee');
            $table->foreignId('dropoff_location_id')
                ->nullable()
                ->references('id')->on('lokasi_penjemputans')
                ->onDelete('set null');
            $table->dateTime('pickup_date_execute')->nullable();
            $table->dateTime('pickup_date');
            $table->double('pickup_location_fee');
            $table->foreignId('pickup_location_id')
                ->nullable()
                ->references('id')->on('lokasi_penjemputans')
                ->onDelete('set null');
            $table->string('status');
            $table->double('total');
            $table->timestamps();

            $table->index('motor_id');
            $table->index('user_id');
            $table->index('user_id', 'status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
