<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('list_motors', function (Blueprint $table) {
            $table->id();
            $table->foreignId('type_motor_id')
                ->nullable() // This makes the column able to store NULL values
                ->references('id')->on('type_motors')
                ->onDelete('set null');
            $table->string('nomor_rangka');
            $table->string('plat_nomor');
            $table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('list_motors');
    }
};
